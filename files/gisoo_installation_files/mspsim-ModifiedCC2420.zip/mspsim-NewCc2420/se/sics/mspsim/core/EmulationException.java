package se.sics.mspsim.core;

public class EmulationException extends RuntimeException {
  private static final long serialVersionUID = -3837451031129913060L;

  public EmulationException(String msg) {
    super(msg);
  }
}
