package se.sics.mspsim.ui;

public interface WindowManager {
  public ManagedWindow createWindow(String name);
}
